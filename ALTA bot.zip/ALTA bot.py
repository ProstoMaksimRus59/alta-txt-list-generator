import sys #тут почти все написала gemma(и правил гемени с дипсиком. хотя тут и от меня фиксы) так как я манал с апи дс работать. и по этому она берет данные с файлов так как это уже на моей стороне.

import discord
from discord.ext import commands
import os
import asyncio # Импортируем asyncio для задержек

import ALTATEXTGENERAGOR
ALTATEXTGENERAGOR.F1()
ALTATEXTGENERAGOR.toppla()
ALTATEXTGENERAGOR.topver()
# --- КОНФИГУРАЦИЯ ---
TOKEN = 'Токен С СКОБКАИИ' 

TARGET_CHANNEL_IDS = [
    топ игроков! без скобок, # ID Канала 1
    топ лвлов! без скобок  # ID Канала 2
]

FILE_MAP = {
    TARGET_CHANNEL_IDS[0]: 'toppla.txt', #Не меняем
    TARGET_CHANNEL_IDS[1]: 'toplvl.txt'
}

MAX_CHUNK_SIZE = 2000
SEPARATOR = "...\n" 


# --- ФУНКЦИИ ЛОГИКИ БОТА ---
# --- ФУНКЦИИ ЛОГИКИ БОТА ---

async def clear_bot_messages(channel: discord.TextChannel, bot_user_id: int):
    """
    Выполняет полную очистку истории канала без ограничений.
    """
    print(f"\n[ОЧИСТКА] Начинается полная очистка истории в канале {channel.name}...")

    try:
        # limit=None убирает лимит в 100 сообщений и удаляет всё, что найдет
        # check=None (по умолчанию) удаляет сообщения всех пользователей
        deleted = await channel.purge(limit=None) 

        print(f"✨ Очистка завершена! Удалено сообщений: {len(deleted)}")
        return True

    except discord.Forbidden:
        print("[ОШИБКА] Нет прав! Боту нужна роль с правом 'Управление сообщениями'.")
        return False
    except Exception as e:
        print(f"[КРИТИЧЕСКАЯ ОШИБКА] Не удалось очистить канал {channel.name}: {e}")
        return False



async def split_and_send(channel: discord.TextChannel, file_path: str, split_marker: str = '.....................'):
    """
    Читает файл и отправляет его в указанный канал, разбивая по определенным местам.
    split_marker - маркер, по которому происходит деление.
    """
    print(f"\n[Обработка] Файл {file_path} для канала {channel.name}")

    if not os.path.exists(file_path):
        print(f"[ОШИБКА] Не найден файл по пути: {file_path}")
        return False 

    try:
        with open(file_path, 'r') as f:
            content = f.read()
    except Exception as e:
        print(f"[КРИТИЧЕСКАЯ ОШИБКА] Не удалось прочитать файл {file_path}: {e}")
        return False

    # Разделяем по маркеру
    parts = content.split(split_marker)

    # Собираем чанки, не превышающие MAX_CHUNK_SIZE
    chunks = []
    current_chunk = ''
    for part in parts:
        # Добавляем разделитель обратно, если нужно
        part_with_marker = part
        if part != parts[-1]:
            part_with_marker += split_marker

        if len(current_chunk) + len(part_with_marker) <= MAX_CHUNK_SIZE:
            current_chunk += part_with_marker
        else:
            if current_chunk:
                chunks.append(current_chunk)
            current_chunk = part_with_marker

    # Добавляем последний кусок
    if current_chunk:
        chunks.append(current_chunk)

    success = True
    for i, chunk in enumerate(chunks):
        try:
            await channel.send(f"\n{chunk}")
            print(f"[УСПЕХ] Отправлен чанк {i+1} в канал '{channel.name}'")
            await asyncio.sleep(3)
        except discord.errors.HTTPException as e:
            print(f"[ОШИБКА API] Не удалось отправить чанк в канал {channel.name}: {e}")
            success = False
            break

    return success


# --- БОТ ИНИЦИАЛИЗАЦИЯ (Без изменений) ---

intents = discord.Intents.default()
intents.message_content = True 
client = commands.Bot(command_prefix='!', intents=intents)


@client.event
async def on_ready():
    """Этот код запускается после успешного подключения бота."""
    print('======================================')
    print('✅ Бот успешно запущен и готов к выполнению скрипта.')
    print(f'ID Бота: {client.user.id}')
    print('======================================')

    # --- ОСНОВНОЙ СЦЕНАРИЙ ЗАПУСКА (Trigger on Enter) ---
    bot_user_id = client.user.id
    results = []

    for channel_id, file_path in FILE_MAP.items():
        channel = client.get_channel(channel_id)
        
        if not channel:
            print(f"\n[КРИТИЧЕСКАЯ ОШИБКА] Не удалось найти канал с ID {channel_id}. Проверьте, что бот в нем.")
            results.append(False)
            continue

        # Шаг 1: Полная очистка истории (Обновленная функция)
        await clear_bot_messages(channel, bot_user_id)

        # Шаг 2: Отправка новых данных
        success = await split_and_send(channel, file_path)
        results.append(success)


    # Финальный отчет (Без изменений)
    if all(results):
        print("\n=============================================")
        print("🚀 ВСЕ ФАЙЛЫ УСПЕШНО ОТПРАВЛЕНЫ И КАНАЛЫ ОЧИЩЕНЫ!")
        print("=============================================")
        exit() #мое а то гемма ЗАБЫЛА ВЫРУБАТЬ БОТА!!!!!!!!!!!!
    else:
        # ... (остальной отчет)
        pass

# --- ЗАПУСК СКРИПТА (Без изменений) ---
client.run(TOKEN)