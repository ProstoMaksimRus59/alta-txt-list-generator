#тут почти все написала gemini так как я манал с апи дс работать. и по этому она берет данные с файлов так как это уже на моей стороне.
import discord
from discord.ext import commands
import os
import asyncio # Импортируем asyncio для задержек

import ALTATEXTGENERAGOR
ALTATEXTGENERAGOR.F1()
ALTATEXTGENERAGOR.toppla()
ALTATEXTGENERAGOR.topver()
# --- КОНФИГУРАЦИЯ ---
TOKEN = 'ТОКЕН' 

TARGET_CHANNEL_IDS = [
    чат1, # ID Канала 1
    чат2  # ID Канала 2
]
FILE_MAP = {
    TARGET_CHANNEL_IDS[0]: 'toppla.txt', 
    TARGET_CHANNEL_IDS[1]: 'toplvl.txt'
}

MAX_CHUNK_SIZE = 2000
SEPARATOR = "...\n" 


# --- ФУНКЦИИ ЛОГИКИ БОТА ---
# --- ФУНКЦИИ ЛОГИКИ БОТА ---

async def clear_bot_messages(channel: discord.TextChannel, bot_user_id: int):
    """
    Выполняет полную очистку истории канала без ограничений.
    """
    print(f"\n[ОЧИСТКА] Начинается полная очистка истории в канале {channel.name}...")

    try:
        # limit=None убирает лимит в 100 сообщений и удаляет всё, что найдет
        # check=None (по умолчанию) удаляет сообщения всех пользователей
        deleted = await channel.purge(limit=None) 

        print(f"✨ Очистка завершена! Удалено сообщений: {len(deleted)}")
        return True

    except discord.Forbidden:
        print("[ОШИБКА] Нет прав! Боту нужна роль с правом 'Управление сообщениями'.")
        return False
    except Exception as e:
        print(f"[КРИТИЧЕСКАЯ ОШИБКА] Не удалось очистить канал {channel.name}: {e}")
        return False



async def split_and_send(channel: discord.TextChannel, file_path: str, split_marker: str = '.....................'):
    """
    Читает файл и отправляет его в указанный канал, разбивая по определенным местам.
    split_marker - основной маркер, fallback_marker - резервный (запятая).
    """
    fallback_marker = ' , '
    print(f"\n[Обработка] Файл {file_path} для канала {channel.name}")

    if not os.path.exists(file_path):
        print(f"[ОШИБКА] Не найден файл по пути: {file_path}")
        return False 

    try:
        with open(file_path, 'r') as f:
            content = f.read()
    except Exception as e:
        print(f"[КРИТИЧЕСКАЯ ОШИБКА] Не удалось прочитать файл {file_path}: {e}")
        return False

    # Сначала пробуем делить по основному маркеру
    initial_parts = content.split(split_marker)
    
    # Проверяем: если части все равно слишком длинные, дробим их по запасному маркеру
    parts = []
    for p in initial_parts:
        if len(p) > MAX_CHUNK_SIZE:
            # Если основной маркер не помог, дробим по запятой
            sub_parts = p.split(fallback_marker)
            for i, sp in enumerate(sub_parts):
                # Добавляем запятую обратно всем, кроме последнего под-куска
                parts.append(sp + (fallback_marker if i < len(sub_parts) - 1 else ""))
        else:
            parts.append(p + (split_marker if p != initial_parts[-1] else ""))

    # Собираем чанки для отправки
    chunks = []
    current_chunk = ''
    for part in parts:
        if len(current_chunk) + len(part) <= MAX_CHUNK_SIZE:
            current_chunk += part
        else:
            if current_chunk:
                chunks.append(current_chunk)
            current_chunk = part

    if current_chunk:
        chunks.append(current_chunk)
        
    # Дальше твой код отправки...

    success = True
    for i, chunk in enumerate(chunks):
        try:
            await channel.send(f"\n{chunk}")
            print(f"[УСПЕХ] Отправлен чанк {i+1} в канал '{channel.name}'")
            await asyncio.sleep(3)
        except discord.errors.HTTPException as e:
            print(f"[ОШИБКА API] Не удалось отправить чанк в канал {channel.name}: {e}")
            success = False
            break

    return success


# --- БОТ ИНИЦИАЛИЗАЦИЯ (Без изменений) ---

intents = discord.Intents.default()
intents.message_content = True 
client = commands.Bot(command_prefix='!', intents=intents)


@client.event
async def on_ready():
    """Этот код запускается после успешного подключения бота."""
    print('======================================')
    print('✅ Бот успешно запущен и готов к выполнению скрипта.')
    print(f'ID Бота: {client.user.id}')
    print('======================================')

    # --- ОСНОВНОЙ СЦЕНАРИЙ ЗАПУСКА (Trigger on Enter) ---
    bot_user_id = client.user.id
    results = []

    for channel_id, file_path in FILE_MAP.items():
        channel = client.get_channel(channel_id)
        
        if not channel:
            print(f"\n[КРИТИЧЕСКАЯ ОШИБКА] Не удалось найти канал с ID {channel_id}. Проверьте, что бот в нем.")
            results.append(False)
            continue

        # Шаг 1: Полная очистка истории (Обновленная функция)
        await clear_bot_messages(channel, bot_user_id)

        # Шаг 2: Отправка новых данных
        success = await split_and_send(channel, file_path)
        results.append(success)


    # Финальный отчет (Без изменений)
    if all(results):
        print("\n=============================================")
        print("🚀 ВСЕ ФАЙЛЫ УСПЕШНО ОТПРАВЛЕНЫ И КАНАЛЫ ОЧИЩЕНЫ!")
        print("=============================================")
        exit() #выбиваю бота принудительно из сети
    else:
        # ... (остальной отчет)
        pass

# --- ЗАПУСК СКРИПТА (Без изменений) ---
client.run(TOKEN)